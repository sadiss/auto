
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        .buttons-csv{
            background: green;
            padding: 10px;
            color: #fff;
            border-radius: 3px;
        }
    </style>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Leads')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container" style="max-width: 1460px;">
        <div class="row">
            <div class="col-sm-12 col-md-12" style="margin-top:30px;">
                <table id="myTable" class="table" >
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email Name</th>
                        <th>Phone</th>
                        <th>Zip</th>
                        <th>URL</th>
                        <th>IP</th>
                        <th>Consent</th>
                        <th>Trust Form URL</th>
                        <th>Universal lead id</th>
                        <th>Crated at</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th><?php echo e($key+1); ?></th>
                            <td><?php echo e($leads->firstName); ?></td>
                            <td><?php echo e($leads->lastName); ?></td>
                            <td><?php echo e($leads->email); ?></td>
                            <td><?php echo e($leads->phone); ?></td>
                            <td><?php echo e($leads->zip); ?></td>
                            <td style="word-break: break-all"><?php echo e($leads->url); ?></td>
                            <td><?php echo e($leads->ipaddress); ?></td>
                            <td><?php echo e($leads->tcpaConsent); ?></td>
                            <td style="word-break: break-all"><a href="<?php echo e($leads->xxTrustedFormCertUrl); ?>" target="_blank"><?php echo e($leads->xxTrustedFormCertUrl); ?></a></td>
                            <td style="word-break: revert"><?php echo e($leads->universal_leadid); ?></td>
                            <td><?php echo e(date('Y-m-d', strtotime($leads->created_at))); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script>
<script src="https://cdn.datatables.net/datetime/1.4.0/js/dataTables.dateTime.min.js    "></script>
<script>
    $.fn.dataTable.ext.search.push(
        function( settings, data, dataIndex ) {
            var min = minDate.val();
            var max = maxDate.val();
            var date = new Date( data[4] );

            if (
                ( min === null && max === null ) ||
                ( min === null && date <= max ) ||
                ( min <= date   && max === null ) ||
                ( min <= date   && date <= max )
            ) {
                return true;
            }
            return false;
        }
    );

    $(document).ready( function () {
        var minDate, maxDate;

// Custom filtering function which will search data in column four between two values
        minDate = new DateTime($('#min'), {
            format: 'YYYY MM Do'
        });
        maxDate = new DateTime($('#max'), {
            format: 'YYYY MM Do'
        });
        var table = $('#myTable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'csv'
            ]
        });

        // Refilter the table
        $('#min, #max').on('change', function () {
            table.draw();
        });
    } );
</script>
<?php /**PATH D:\projects\Fiverr\auto-insurance\resources\views/Leads.blade.php ENDPATH**/ ?>